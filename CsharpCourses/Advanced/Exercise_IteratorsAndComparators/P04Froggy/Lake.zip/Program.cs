﻿using System;
using System.Linq;

namespace P04Froggy
{
    class Program
    {
        static void Main(string[] args)
        {
            var stones = Console.ReadLine()
                                .Split(", ", StringSplitOptions.RemoveEmptyEntries)
                                .Select(int.Parse)
                                .ToList();
            var lake = new Lake(stones);

            foreach (var item in lake)
            {
                Console.Write($"{item}, ");
            }
        }
    }
}
