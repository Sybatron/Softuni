﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CustomAnimation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            var shop = new Shop(new Point(200, 100), new Size(500, 300), new SolidBrush(Color.SaddleBrown), ref g);
            var window = new Window(50, new SolidBrush(Color.Aqua));
            shop.addWindow(window);
            shop.windows[0].position = new Point(shop.original.X + 10, shop.original.Y + 50);

            shop.addWindow(window);
            shop.windows[1].position = new Point(shop.original.X + shop.original.Width - 10, shop.original.Y + 50);
            g.FillRectangle(shop.windows[0].brush, new Rectangle(shop.windows[0].position, shop.windows[0].size));
            g.FillRectangle(shop.windows[1].brush, new Rectangle(shop.windows[1].position, shop.windows[1].size));
        }
    }

    public class Window
    {
        public Size size;
        public Point position = new Point(0, 0);
        public SolidBrush brush;

        public Window(int side, SolidBrush inputBrush)
        {
            size = new Size(side,side);
            brush = inputBrush;
        }
    }
    public class Door
    {
        public Size size;
        public Point position = new Point(0, 0);
        public SolidBrush brush;

        public Door(Size inputSize, SolidBrush inputBrush)
        {
            size = inputSize;
            brush = inputBrush;
        }
    }
    public class Shop
    {
        public List<Window> windows = new List<Window>();
        public List<Door> doors = new List<Door>();
        public Rectangle original;

        public Shop(Point posOrig, Size sizeOrig, SolidBrush brush, ref Graphics g)
        {
            original = new Rectangle(posOrig, sizeOrig);
            g.FillRectangle(brush, original);
        }
        public void addWindow(Window window)
        {
            windows.Add(window);
        }
        public void addDoor(Door door)
        {
            doors.Add(door);
        }
        public void OpenDoors(ref Graphics g, int freq)
        {
            if (doors.Count == 2)
            {
                for (int i = 0; i < 10; i++)
                {
                    doors[0].position.X -= 10;
                    doors[1].position.X += 10;
                    g.FillRectangle(doors[0].brush, new Rectangle(doors[0].position, doors[0].size));
                    g.FillRectangle(doors[1].brush, new Rectangle(doors[1].position, doors[1].size));
                    g.FillRectangle(Brushes.Gold,
                        new Rectangle(new Point(doors[0].position.X + doors[0].size.Width, doors[0].position.Y),
                            new Size(doors[1].position.X, doors[1].position.Y)));
                    System.Threading.Thread.Sleep(freq);
                }
            }
        }
        public void CloseDoors(ref Graphics g, int freq)
        {
            if (doors.Count == 2)
            {
                for (int i = 0; i < 10; i++)
                {
                    doors[0].position.X += 10;
                    doors[1].position.X -= 10;
                    g.FillRectangle(doors[0].brush, new Rectangle(doors[0].position, doors[0].size));
                    g.FillRectangle(doors[1].brush, new Rectangle(doors[1].position, doors[1].size));
                    g.FillRectangle(Brushes.Gold,
                        new Rectangle(new Point(doors[0].position.X + doors[0].size.Width, doors[0].position.Y),
                            new Size(doors[1].position.X, doors[1].position.Y)));
                    System.Threading.Thread.Sleep(freq);
                }
            }
        }

    }

}
